
package com.example.smsreader
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Telephony
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        setContentView(tv)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_SMS), 1)
        } else {
            tv.text = readSms()
        }
    }
    override fun onRequestPermissionsResult(code:Int, p:Array<out String>, r:IntArray){
        super.onRequestPermissionsResult(code,p,r)
        if (code==1 && r.isNotEmpty() && r[0]==PackageManager.PERMISSION_GRANTED){
            (findViewById(android.R.id.content) as TextView).text = readSms()
        }
    }
    private fun readSms(): String {
        val sb = StringBuilder()
        val cursor = contentResolver.query(Telephony.Sms.CONTENT_URI,null,null,null,null)
        cursor?.use {
            val body = it.getColumnIndexOrThrow(Telephony.Sms.BODY)
            while (it.moveToNext()) sb.append(it.getString(body)).append("\n\n")
        }
        return sb.toString()
    }
}
